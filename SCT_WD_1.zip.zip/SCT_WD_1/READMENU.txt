# SkillCraft Task 02 – Stopwatch Web Application

# Live Demo
[View on CodePen](https://codepen.io/Kavyashree-Halburge/pen/qEbpgdK)

# Features
- Start, pause, and reset stopwatch
- Lap time tracking
- Accurate time recording

# Tech Used
HTML, CSS, JavaScript

# Author
Kavyashree – B.E. AIML Student at Sai Vidya Institute of Technology

